const axios = require("axios");

const deviceInfo = {
  imei: "37B241FB-F9D1-4CB2-A72F-C79496D0ED47",
  os: "iOS",
  osVersion: "12.4.1",
  alias: "iPhone 7",
  appVersion: "2.0.6",
};

const loginInfo = {
  username: "gfwangyang",
  password: "WangYang_2022",
  from: "mobile",
  vcode: "",
  device: deviceInfo,
};

const reportInfo = {
  staff_type: "定职级",
  username: "王扬",
  department: "信息技术部",
  group_name: "信息技术部终端综合业务研发组",
  native_place: "湖北",
  work_city: "广东深圳",
  vaccine: "第二针",
  no_vaccine_reason: "",
  recent_leave_work_place: "否",
  is_stay_epidemic_area: "否",
  contact: "否",
  contact_diagnose: "否",
  housing_diagnose: "否",
  is_NAT_check: "是",
  NAT_check_time: "2021-06-08T02:55:20.354Z",
  NAT_report_time: "",
  local_report: "是",
  isolation: "否",
  health_abnormal: "0",
  hospitalization: "否",
  attendance_type: "休假",
  floor: "深圳中洲8楼",
  contact_person: "",
  remarks: "",
  branch_leader: "杜瑞罡",
  travel_mode: "自驾",
  recent_transport: "",
  eat_in: "",
  epidemic_area_name: "",
  oa: "gfwangyang",
  erp: "29961",
  work_type_name: "研发岗",
};

let cookies = {};
const getCookieString = () => {
  let kvs = [];
  for (const k in cookies) {
    kvs.push(`${k}=${cookies[k]}`);
  }
  return kvs.join("; ");
};
const addCookie = (setCookies) => {
  if (setCookies && setCookies.length) {
    setCookies.forEach((cookie) => {
      const c = cookie.split(";")[0];
      const i = c.indexOf("=");
      const name = c.substring(0, i);
      const value = c.substring(i + 1);
      cookies[name] = value;
    });
  }
};
const login = async () => {
  return await axios
    .post(`https://mportal.gf.com.cn/services/moa/sso/v2/login`, loginInfo)
    .then((res) => {
      const headers = res.headers;
      const setCookies = headers["set-cookie"];
      addCookie(setCookies);
    });
};

const getOaToken = async () => {
  // console.log("cookies", getCookieString());
  return await axios
    .get(`https://support.gf.com.cn/api/aya/auth/oa_user_info?`, {
      headers: { Cookie: getCookieString() },
    })
    .then((res) => {
      const headers = res.headers;
      const setCookies = headers["set-cookie"];
      addCookie(setCookies);
      // console.log(res.data);
    })
    .catch((e) => console.log("eeeee", e));
};

const reportHealth = async () => {
  const isWeekend = [0, 6].indexOf(new Date().getDay()) > -1;
  const info = {
    ...reportInfo,
    attendance_type: isWeekend ? "休假" : "现场办公--一天",
  };
  return await axios.post(
    `https://support.gf.com.cn/api/aya/staff_sheet`,
    info
  ).then(res=>{
    return res.data;
  })
};

(async () => {
  await login();
  await getOaToken();
  const reportResult = await reportHealth();
  console.log('rs', reportResult);
})();
